from http.client import responses
import imp
from unittest import result
from django.shortcuts import render
import json
import requests

# Create your views here.
def index(request):
    return render(request,'index.html')

def add(request):
    val1=int(request.POST['num1'])
    val2=int(request.POST['num2'])
    result=val1+val2
    return render (request, 'add.html',{'Result':result})

def api(request):
    response=requests.get('https://api.covid19api.com/live/country/south-africa/status/confirmed').json()
    return render(request,'api.html',{'Response':response})