from unicodedata import name
from django.urls import path
from . import views

urlpatterns= [
    path('login',views.login, name='login'),
    path('logout',views.logout, name='logout'),
    path('registration',views.registration, name='registration'),
    path('application',views.application,name='application'),
    path('signup',views.signup,name='signup'),   
    path('survey',views.survey,name='survey'),
    path('display',views.display,name='display'),
]
